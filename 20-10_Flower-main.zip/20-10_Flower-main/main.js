onload = () =>{
        document.body.classList.remove("container");
};
// set up text to print, each item in array is new line
